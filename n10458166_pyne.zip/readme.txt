LaughTrackr Website References. 

Here is a list of sources used to create my Assessment 1 for IAB207 Rapid Web Development.

For HTML Formatting:
Long, J. (2017, 04). Homepage. Prettier. https://prettier.io/ 

Bootstrap and CSS elements:
MIT. (2021). Bootstrap. Get started any way you want. https://getbootstrap.com/ 
Refsnes Data. (2025). CSS Tutorial. W3Schools. https://www.w3schools.com/css/default.asp 

Placeholder Event Images and Details:
Google. (2025). Image Search. Google Images. https://www.google.com/imghp?hl=en-GB&tab=ri&authuser=0&ogbl 
McIvor, H. (2025). Tour. Randy Feltface. https://www.feltface.com/ 
Ruane, Z., Kelly, B., & Bonanno, M. (2025). World Tour. Aunty Donna. https://tour.auntydonna.com/ 
Refsnes Data. (2025). JavaScript DOM EventListener. W3Schools. https://www.w3schools.com/js/js_htmldom_eventlistener.asp 